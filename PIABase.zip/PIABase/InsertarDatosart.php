<!DOCTYPE html>
<html>
<head>
	<title> Dato insertado </title>
</head>
<body>

<?php
$con = mysqli_connect("Localhost", "root", "", "electronica");
$sql = "INSERT INTO articulos
VALUES ('$_POST[clave_art]', '$_POST[desc_art]', '$_POST[cantidad_art]', '$_POST[proveedor_art]')";
if (!mysqli_query($con, $sql, MYSQLI_USE_RESULT)) {
	die('Error: ' .mysqli_error($con));
}
echo "<center>";
echo "1 Registro Agregado<br><br><br>";
echo "<a href='http://localhost/PIABase/Inicio_sesion.html'>Ver Registros</a>";
mysqli_close($con);
	?>
</body>
</html>