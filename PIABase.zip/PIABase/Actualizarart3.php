
<?php

$con=mysqli_connect("localhost","root", "", "electronica");

if(!$con){
	echo "fallo";
	die(mysqli_error($con));
}

$clave_art = $_POST['clave_art']; 
$desc_art = $_POST['desc_art']; 
$cantidad_art = $_POST['cantidad_art']; 
$proveedor_art = $_POST['proveedor_art'];  

echo "$clave_art $desc_art $cantidad_art $proveedor_art";

$SQLQ = "UPDATE articulos SET  clave_art = '$clave_art', desc_art = '$desc_art', cantidad_art = '$cantidad_art', proveedor_art = '$proveedor_art' WHERE clave_art='$clave_art'";
mysqli_query($con , $SQLQ);

header("Location:Actualizarart1.php"); 
mysqli_close($con);
?>