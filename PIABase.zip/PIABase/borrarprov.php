
<!DOCTYPE html>
<html>
<head>
	<title>Dato borrado</title>
</head>
<body>
<?php
	$con = mysqli_connect("localhost", "root", "","electronica"); 
	echo "<br> <center>";
	if (!$con) {
		die('No se establecio la conexion con el servidor:'.mysqli_error($con)); 

	}

	$sql = "DELETE FROM proveedores WHERE clave_prov = '{$_POST["clave_prov"]}'";
	if (!mysqli_query($con, $sql, MYSQLI_USE_RESULT)) {
		die('Error: '.mysqli_error($con)); 

	}

	echo "Registro Borrado <br> <br>";
	echo "<a href='menu.php'> Ver Registro </a>";
	mysqli_close($con); 
?>

</body>
</html>
