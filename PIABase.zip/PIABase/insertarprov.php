<!DOCTYPE html>
<html>
<head>
	<title>Insertar los registros</title>
	<meta charset="utf-8">
	<link href="estilos.css">
</head>
<style>
	body{
  text-align: center;
  color: white;
  font-family: 'Roboto Slab', serif;
  background-color: #000000;
background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='250' height='30' viewBox='0 0 1000 120'%3E%3Cg fill='none' stroke='%23222' stroke-width='10' %3E%3Cpath d='M-500 75c0 0 125-30 250-30S0 75 0 75s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3Cpath d='M-500 45c0 0 125-30 250-30S0 45 0 45s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3Cpath d='M-500 105c0 0 125-30 250-30S0 105 0 105s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3Cpath d='M-500 15c0 0 125-30 250-30S0 15 0 15s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3Cpath d='M-500-15c0 0 125-30 250-30S0-15 0-15s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3Cpath d='M-500 135c0 0 125-30 250-30S0 135 0 135s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3C/g%3E%3C/svg%3E");
}


.card {
  margin: 7rem auto;
  width: 50rem;
  height: 39rem;
  background-image: linear-gradient(163deg, #00ff75 0%, #3700ff 100%);
  border-radius: 20px;
  transition: all .3s;
 }
 
 .card2 {

  width: 50rem;
  height: 39rem;
  background-color: #1a1a1a;
  transition: all .2s;
 }
 
 .card2:hover {
  transform: scale(0.98);
  border-radius: 20px;
 }
 
 .card:hover {
  box-shadow: 0px 0px 30px 1px rgba(0, 255, 117, 0.30);
 }
 
 .inputbox {
  margin-top: 4rem;
  margin-left: 15rem;
  position: relative;
  width: 196px;
}

.inputbox input {
  position: relative;
  width: 100%;
  padding: 20px 10px 10px;
  background: transparent;
  outline: none;
  box-shadow: none;
  border: none;
  color: #23242a;
  font-size: 1em;
  letter-spacing: 0.05em;
  transition: 0.5s;
  z-index: 10;
}

.inputbox span {
  position: absolute;
  left: 0;
  padding: 20px 10px 10px;
  font-size: 1em;
  color: #8f8f8f;
  letter-spacing: 00.05em;
  transition: 0.5s;
  pointer-events: none;
}

.inputbox input:valid ~span,
.inputbox input:focus ~span {
  color: #45f3ff;
  transform: translateX(-10px) translateY(-34px);
  font-size: 0,75em;
}

.inputbox i {
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 2px;
  background: #45f3ff;
  border-radius: 4px;
  transition: 0.5s;
  pointer-events: none;
  z-index: 9;
}

.inputbox input:valid ~i,
.inputbox input:focus ~i {
  height: 44px;
}
button{
  margin-top: 5rem;
}
button {
  position: relative;
  padding: 1em 1.8em;
  outline: none;
  border: 1px solid #303030;
  background: #212121;
  color: #ae00ff;
  text-transform: uppercase;
  letter-spacing: 2px;
  font-size: 15px;
  overflow: hidden;
  transition: 0.2s;
  border-radius: 20px;
  cursor: pointer;
  font-weight: bold;
 }
 
 button:hover {
  box-shadow: 0 0 10px #ae00ff, 0 0 25px #001eff, 0 0 50px #ae00ff;
  transition-delay: 0.6s;
 }
 
 button span {
  position: absolute;
 }
 
 button span:nth-child(1) {
  top: 0;
  left: -100%;
  width: 100%;
  height: 2px;
  background: linear-gradient(90deg, transparent, #ae00ff);
 }
 
 button:hover span:nth-child(1) {
  left: 100%;
  transition: 0.7s;
 }
 
 button span:nth-child(3) {
  bottom: 0;
  right: -100%;
  width: 100%;
  height: 2px;
  background: linear-gradient(90deg, transparent, #001eff);
 }
 
 button:hover span:nth-child(3) {
  right: 100%;
  transition: 0.7s;
  transition-delay: 0.35s;
 }
 
 button span:nth-child(2) {
  top: -100%;
  right: 0;
  width: 2px;
  height: 100%;
  background: linear-gradient(180deg, transparent, #ae00ff);
 }
 
 button:hover span:nth-child(2) {
  top: 100%;
  transition: 0.7s;
  transition-delay: 0.17s;
 }
 
 button span:nth-child(4) {
  bottom: -100%;
  left: 0;
  width: 2px;
  height: 100%;
  background: linear-gradient(360deg, transparent, #001eff);
 }
 
 button:hover span:nth-child(4) {
  bottom: 100%;
  transition: 0.7s;
  transition-delay: 0.52s;
 }
 
 button:active {
  background: #ae00af;
  background: linear-gradient(to top right, #ae00af, #001eff);
  color: #bfbfbf;
  box-shadow: 0 0 8px #ae00ff, 0 0 8px #001eff, 0 0 8px #ae00ff;
  transition: 0.1s;
 }
 
 button:active span:nth-child(1) 
 span:nth-child(2) 
 span:nth-child(2) 
 span:nth-child(2) {
  transition: none;
  transition-delay: none;
 }
</style>



<body class="cuerpo">
	<div class="card">
		<div class="card2">
				<h1>Ingresar Datos Proveedores</h1>
<form action="insertardatosprov.php"method="post">

<div class="inputbox">
	<span>Clave</span>
<input required="required" type="text" name="clave_prov"> 
<i></i>
</div>

<div class="inputbox">
	<span>ClaveArt</span>
<input required="required" type="text" name="claveart_prov"> 
<i></i>
</div>

<div class="inputbox">
	<span>Cantidad</span>
<input required="required" type="text" name="tipo_prov"> 
<i></i>
</div>


<div class="inputbox">
	<span>Email</span>
<input required="required" type="text" name="email_prov"> 
<i></i>
</div>

<div class="inputbox">
	<span>Telefono</span>
<input required="required" type="text" name="telefono_prov"> 
<i></i>
</div>



<button href="insertardatosprov.php" name="Enviar">
<span></span>
<span></span>
<span></span>
<span></span> Grabar
</button>
</form>
		</div>
	  </div>

</body>
</html>