
<?php

$con=mysqli_connect("localhost","root", "", "electronica");

if(!$con){
	echo "fallo";
	die(mysqli_error($con));
}

$clave_vta = $_POST['clave_vta']; 
$cantidad_vta = $_POST['cantidad_vta']; 
$claveprov_vta = $_POST['claveprov_vta']; 
$total_vta = $_POST['total_vta']; 

$SQLQ = "UPDATE ventas SET  clave_vta = '$clave_vta', cantidad_vta = '$cantidad_vta', claveprov_vta = '$claveprov_vta', total_vta = '$total_vta'  WHERE clave_vta='$clave_vta'";
mysqli_query($con , $SQLQ);

header("Location:actualizarvta1.php"); 
mysqli_close($con);
?>