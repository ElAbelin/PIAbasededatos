<!DOCTYPE html>
<html>
<head>
	<title> Dato insertado </title>
</head>
<body>

<?php
$con = mysqli_connect("Localhost", "root", "", "electronica");
$sql = "INSERT INTO ventas
VALUES ('$_POST[clave_vta]', '$_POST[cantidad_vta]', '$_POST[claveprov_vta]', '$_POST[total_vta]')";
if (!mysqli_query($con, $sql, MYSQLI_USE_RESULT)) {
	die('Error: ' .mysqli_error($con));
}
echo "<center>";
echo "1 Registro Agregado<br><br><br>";
echo "<a href='http://localhost/PIABase/Inicio_sesion.html'>Ver Registros</a>";
mysqli_close($con);
	?>
</body>
</html>