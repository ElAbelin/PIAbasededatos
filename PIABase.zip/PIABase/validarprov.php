<!DOCTYPE html>
<html>
<head>
	<title> Tabla Pacientes</title>
	<link href="estilos.css">
</head>
<body>
<div class="wrap">

<nav class="navegacion">
  <ul class="primary">
  <li>
  <a href="http://localhost/PIABase/Inicio_sesion.html">Inicio</a>
  </li>
    <li>
      <a href="">Tabla Articulos</a>
      <ul class="sub">
        <li><a href="http://localhost/PIABase/Inicio_sesion_electronica(PIA)Consultas.html">Consulta</a></li>
        <li><a href="http://localhost/PIABase/Inicio_sesion_electronica(PIA)insertarart.html">Insertar</a></li>
        <li><a href="http://localhost/PIABase/Inicio_sesion_electronica(PIA)borrarart.html">Eliminar</a></li>
        <li><a href="http://localhost/PIABase/Actualizararticulos.html">Modificar</a></li>
      </ul>
    </li>
    <li>
      <a href="">Tabla Proveedores</a>
      <ul class="sub">
        <li><a href="http://localhost/PIABase/inicio_consultas_prov.html">Consulta</a></li>
        <li><a href="http://localhost/PIABase/inicio_insertar_prov.html">Insertar</a></li>
        <li><a href="http://localhost/PIABase/inicio_borrar_prov.html">Eliminar</a></li>
        <li><a href="http://localhost/PIABase/actualizarprov.html">Modificar</a></li>
      </ul>
    </li>
    <li>
      <a href="">Tabla Ventas</a>
      <ul class="sub">
        <li><a href="http://localhost/PIABase/inicio_consultas_vta.html">Consulta</a></li>
        <li><a href="http://localhost/PIABase/inicio_insertar_vta.html">Insertar</a></li>
        <li><a href="http://localhost/PIABase/inicio_borrar_vta.html">Eliminar</a></li>
        <li><a href="http://localhost/PIABase/actualizarvta.html">Modificar</a></li>
      </ul>  
    </li>
</nav>
</div>
<style>
	body{
  text-align: center;
  color: white;
  font-family: 'Roboto Slab', serif;
  background-color: #000000;
background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='250' height='30' viewBox='0 0 1000 120'%3E%3Cg fill='none' stroke='%23222' stroke-width='10' %3E%3Cpath d='M-500 75c0 0 125-30 250-30S0 75 0 75s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3Cpath d='M-500 45c0 0 125-30 250-30S0 45 0 45s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3Cpath d='M-500 105c0 0 125-30 250-30S0 105 0 105s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3Cpath d='M-500 15c0 0 125-30 250-30S0 15 0 15s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3Cpath d='M-500-15c0 0 125-30 250-30S0-15 0-15s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3Cpath d='M-500 135c0 0 125-30 250-30S0 135 0 135s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3C/g%3E%3C/svg%3E");
}
.navegacion{
  font-family: 'Roboto Slab', serif;
  font-weight: bold;
}
 
.wrap {
  display: inline-block;
  margin-top: 40px;
}
h1{
  font-family: 'Playfair Display SC', serif;
}

/* a little "umph" */


a {
  text-decoration: none;
  color: #fff;
  display: block;
  padding: 4rem;
  font-size: 1.5rem;
}
a:hover{
  border: solid #000;
  padding: 4rem;
}

ul {
  list-style: none;
  position: relative;
  text-align: left;
}

li {
  float: left;
}

/* clear'n floats */
ul:after {
  clear: both;
}

ul:before,
ul:after {
    content: " ";
    display: table;
}

nav {
  position: relative;
  background: #48D1CC;
  text-align: center;
  letter-spacing: 1px;
  text-shadow: 1px 1px 1px #0E0E0E;
  -webkit-box-shadow: 2px 2px 3px #888;
  -moz-box-shadow: 2px 2px 3px #888;
  box-shadow: 2px 2px 3px #888;
  border-bottom-right-radius: 8px;
  border-bottom-left-radius: 8px;
  border-radius: 4rem;
}

/* prime */
ul.primary li a {
  display: block;
  padding: 20px 30px;
}

ul.primary li:last-child a {
  border-right: none;
}

ul.primary li a:hover {
  
  color: #000;
}

/* subs */
ul.sub {
  position: absolute;
  z-index: 200;
  box-shadow: 2px 2px 0 white;
  width: 35%;
  display:none;
}

ul.sub li {
  float: none;
  margin: 0;
}

ul.sub li a {
  border-bottom: 1px dotted #ccc;
  border-right: none;
  color: #000;
  padding: 15px 30px;
}

ul.sub li:last-child a {
  border-bottom: none;
}

ul.sub li a:hover {
  color: #000;
  background: #eeeeee;
}

/* sub display*/
ul.primary li:hover ul {
  display: block;
  background: transparent;
}

/* keeps the tab background white */
ul.primary li:hover a {
  background: 	#4B0082;
  border-radius: 4rem;
  color: white;
  text-shadow: none;
}

ul.primary li:hover > a{
  color: #000;
} 

@media only screen and (max-width: 600px) {
  .decor {
    padding: 3px;
  }
  
  
  .wrap {
    width: 100%;
    margin-top: 0px;
  }
  
   li {
    float: none;
  }
  
  ul.primary li:hover a {
    background: none;
    color: #8B8B8B;
    text-shadow: 1px 1px #000;
  }

  ul.primary li:hover ul {
    display: block;
    background: #272727;
    color: #fff;
  }
  
  ul.sub {
    display: block;  
    position: static;
    box-shadow: none;
    width: 100%;
  }
  
  ul.sub li a {
    background: #272727;
    border: none;
    color: #8B8B8B;
  }
  
  ul.sub li a:hover {
    color: #ccc;
    background: none;
  }
}
table{
	background-color: #1E90FF;
	border-color:white;
	color:black;
}
 
	</style>

<?php
echo "<center<<br><font face = 'arial'>";
$nom = $_POST['nombre2'];
$pass = $_POST['password2'];
if ($nom=="Abel" and $pass=="123"){
	$con = mysqli_connect("localhost", "root", "", "electronica");
	$resultado = mysqli_query($con, "select * from proveedores");
	echo "<center><font color=white><h1>Bienvenido  ".$nom." </h1>";
	if($resultado === FALSE){
		echo "Fallo";
	}
	echo "<center><font face = 'arial'>";
	echo "<font color=white><h3>Consulta de la Tabla de Proveedores </h3>";
	echo "<table border = '1'>
	<tr>
	<th>clave_prov</th>
	<th>claveart_prov</th>
	<th>tipo_prov</th>
	<th>email_prov</th>
    <th>telefono_prov</th>
	</tr>";
	while($row = mysqli_fetch_array($resultado)){
		echo "<tr>";
		echo "<td align = center>".$row['clave_prov']."</td>";
		echo "<td>".$row['claveart_prov']."</td>";
		echo "<td>".$row['tipo_prov']."</td>";
		echo "<td>".$row['email_prov']."</td>";
        echo "<td>".$row['telefono_prov']."</td>";
		echo "</tr>";
	}
	echo "</table>";
	$registros = mysqli_num_rows($resultado);
	echo "<br>Registros: ".$registros,"<br><br>"; 
	mysqli_close($con);
}
else
{
	echo "<h2>Error, usuario y/o contraseña incorrecta</h2>";
	echo "<a href='http://localhost/PIABase/Inicio_sesion.html'>Regresar</a>";
	die(mysqli_error());
}
?>
</body>
</html