
<?php

$con=mysqli_connect("localhost","root", "", "electronica");

if(!$con){
	echo "fallo";
	die(mysqli_error($con));
}

$clave_prov = $_POST['clave_prov']; 
$claveart_prov = $_POST['claveart_prov']; 
$tipo_prov = $_POST['tipo_prov']; 
$email_prov = $_POST['email_prov']; 
$telefono_prov = $_POST['telefono_prov'];   

$SQLQ = "UPDATE proveedores SET  clave_prov = '$clave_prov', claveart_prov = '$claveart_prov', tipo_prov = '$tipo_prov', email_prov = '$email_prov' , telefono_prov ='$telefono_prov' WHERE clave_prov='$clave_prov'";
mysqli_query($con , $SQLQ);

header("Location:actualizarprov1.php"); 
mysqli_close($con);
?>