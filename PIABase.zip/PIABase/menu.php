<meta charset="utf-8">
<html>
  <head>
    <title>Producto Integrador De Aprendizaje</title>
    

    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400;700&display=swap" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display+SC:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="estilos.css">

  </head>
  <meta name="viewport" content="width=device-width">
  <style>
    img{
      width:30rem;
    }
    </style>
  <img src="https://logodix.com/logo/1763306.png">
<header>
<div class="wrap">

<nav class="navegacion">
  <ul class="primary">
  <li>
  <a href="http://localhost/PIABase/Inicio_sesion.html">Inicio</a>
  </li>
    <li>
      <a href="">Tabla Articulos</a>
      <ul class="sub">
        <li><a href="http://localhost/PIABase/Inicio_sesion_electronica(PIA)Consultas.html">Consulta</a></li>
        <li><a href="http://localhost/PIABase/Inicio_sesion_electronica(PIA)insertarart.html">Insertar</a></li>
        <li><a href="http://localhost/PIABase/Inicio_sesion_electronica(PIA)borrarart.html">Eliminar</a></li>
        <li><a href="http://localhost/PIABase/Actualizararticulos.html">Modificar</a></li>
      </ul>
    </li>
    <li>
      <a href="">Tabla Proveedores</a>
      <ul class="sub">
        <li><a href="http://localhost/PIABase/inicio_consultas_prov.html">Consulta</a></li>
        <li><a href="http://localhost/PIABase/inicio_insertar_prov.html">Insertar</a></li>
        <li><a href="http://localhost/PIABase/inicio_borrar_prov.html">Eliminar</a></li>
        <li><a href="http://localhost/PIABase/actualizarprov.html">Modificar</a></li>
      </ul>
    </li>
    <li>
      <a href="">Tabla Ventas</a>
      <ul class="sub">
        <li><a href="http://localhost/PIABase/inicio_consultas_vta.html">Consulta</a></li>
        <li><a href="http://localhost/PIABase/inicio_insertar_vta.html">Insertar</a></li>
        <li><a href="http://localhost/PIABase/inicio_borrar_vta.html">Eliminar</a></li>
        <li><a href="http://localhost/PIABase/actualizarvta.html">Modificar</a></li>
      </ul>  
    </li>
</nav>
</div>
    <br>
    <br>
 
</header>
  </body>
</html>
		