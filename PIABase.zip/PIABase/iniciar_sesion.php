<html>
    <head>
        <link href="estilos.css">
    </head>
<body>
    <style>
        a{
            text-decoration:none;
            color:white;
        }
        body{
            background-color: #000000;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='250' height='30' viewBox='0 0 1000 120'%3E%3Cg fill='none' stroke='%23222' stroke-width='10' %3E%3Cpath d='M-500 75c0 0 125-30 250-30S0 75 0 75s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3Cpath d='M-500 45c0 0 125-30 250-30S0 45 0 45s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3Cpath d='M-500 105c0 0 125-30 250-30S0 105 0 105s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3Cpath d='M-500 15c0 0 125-30 250-30S0 15 0 15s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3Cpath d='M-500-15c0 0 125-30 250-30S0-15 0-15s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3Cpath d='M-500 135c0 0 125-30 250-30S0 135 0 135s125 30 250 30s250-30 250-30s125-30 250-30s250 30 250 30s125 30 250 30s250-30 250-30'/%3E%3C/g%3E%3C/svg%3E");
}
        b {
            color:white;
            font-size:2rem;
        }
        h2{
            color:white;
        }

        button {
 position: relative;
 font-size: 14px;
 letter-spacing: 3px;
 height: 3em;
 padding: 0 3em;
 border: none;
 background-color: #c41b54;
 color: #fff;
 text-transform: uppercase;
 overflow: hidden;
 border-radius: 5px
}

button::before {
 content: '';
 display: block;
 position: absolute;
 z-index: 0;
 bottom: 0;
 left: 0;
 height: 0px;
 width: 100%;
 background: rgb(196,27,84);
 background: linear-gradient(90deg, rgba(196,27,84,1) 20%, rgba(124,7,46,1) 100%);
 transition: 0.2s;
}

button .label {
 position: relative;
}

button .icon {
 display: flex;
 align-items: center;
 justify-content: center;
 height: 3em;
 width: 3em;
 position: absolute;
 top: 3em;
 right: 0;
 opacity: 0;
 transition: 0.4s;
}

button:hover::before {
 height: 100%;
}

button:hover .icon {
 top: 0;
 opacity: 1;
}
    </style>
<?php
	echo "<center> <br><br>";
	$nom=$_POST['nombre2'];
	$pass=$_POST['password2'];

	if ($nom=="Abel" and $pass=="123"){
		$con = mysqli_connect("localhost", "root", "", "electronica");
		echo "<p class='texto'>";
		echo " <b>Bienvenido al servidor " .$nom. "</b>";
		echo "</p>";
	}

	else {
		echo "<h2> Fallo, usuario o contraseña incorrecta </h2>";
		echo "<a href='inicio_sesion.html'> Regresar </a>";
		die(mysqli_error());
	}
?>
<br>
<br>

<button>
 <a href="menu.php" target="_parent" ><span class="label">Next</span>
  <span class="icon">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill="none" d="M0 0h24v24H0z"></path><path fill="currentColor" d="M16.172 11l-5.364-5.364 1.414-1.414L20 12l-7.778 7.778-1.414-1.414L16.172 13H4v-2z"></path></svg>
  </span>
</button>
</body>